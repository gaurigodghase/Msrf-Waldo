
waldo - v1 2021-08-17 12:01am
==============================

This dataset was exported via roboflow.ai on August 16, 2021 at 6:32 PM GMT

It includes 31 images.
Waldo are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


